仿真实现目标点导航可视化步骤：
1. gazebo搭建一个场景(worlds)，然后用gmapping+teleop/exploring移动建图(maps)。worlds用于mbot_laser_nav_gazebo，maps用于nav_demo。
2. 遥控至目标点附近，get-pose得到目标点的坐标。
3. 运行gazebo和nav，打开四个发布者marker1-4，使rviz上4个点高亮。
4. 最终运行目标点导航脚本。

