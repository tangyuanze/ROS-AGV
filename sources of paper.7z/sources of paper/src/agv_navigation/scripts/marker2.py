#!/usr/bin/env python
#coding=utf-8
 
import rospy
 
#导入显示消息类型，这里主要是Marker消息类型
from visualization_msgs.msg import *
 
#main
if __name__=="__main__":
 
	#初始化节点，anonymous为True，避免重复名字
	rospy.init_node("cube2", anonymous=True)
	
	#发布频率
	rate = rospy.Rate(1)
	
	#定义发布者，发布话题：/cube，消息类型是：Marker,消息队列长度：10
	marker_pub2 = rospy.Publisher("/cube2", Marker, queue_size=10)
	
	rospy.loginfo("Initializing...")

#定义一个marker对象，并初始化各种Marker的特性
	marker = Marker()
	marker.header.frame_id = "/map"
	marker.header.stamp = rospy.Time.now()
	marker.ns = "basic_shapes"
	marker.id = 1	
	#Marker的类型，有ARROW，CUBE等
	marker.type = Marker.CYLINDER
	marker.scale.x = 0.25
	marker.scale.y = 0.25
	marker.scale.z = 0.2	
	#Marker的动作类型有ADD，DELETE等
	marker.action = Marker.ADD
	marker.pose.position.x = -1.56
	marker.pose.position.y = 0.21
	marker.pose.position.z = 0.2
	marker.pose.orientation.x = 0.0
	marker.pose.orientation.y = 0.0
	marker.pose.orientation.z = 0.0
	marker.pose.orientation.w = 1.0
	marker.color.r = 1.0
	marker.color.g = 0.0
	marker.color.b = 0.0
	marker.color.a = 0.8	
	#Marker被自动销毁之前的存活时间，rospy.Duration()意味着在程序结束之前一直存在
	marker.lifetime = rospy.Duration()

	while not rospy.is_shutdown():
		marker_pub2.publish(marker)

		rate.sleep()

