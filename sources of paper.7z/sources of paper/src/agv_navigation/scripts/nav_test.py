#!/usr/bin/env python
import rospy
import actionlib
from actionlib_msgs.msg import *
from geometry_msgs.msg import Pose, PoseWithCovarianceStamped, Point, Quaternion, Twist
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from random import sample
from math import pow, sqrt
from getpose import Robot


class NavTest():
    def __init__(self):
        rospy.init_node('nav_test', anonymous=True)
        
        rospy.on_shutdown(self.shutdown)
        
        # How long in seconds should the robot pause at each location?
        self.rest_time = rospy.get_param("~rest_time", 5)
        
        # Are we running in the fake simulator?
        self.fake_test = rospy.get_param("~fake_test", False)
        
        # Goal state return values
        goal_states = ['PENDING', 'ACTIVE', 'PREEMPTED', 
                       'SUCCEEDED', 'ABORTED', 'REJECTED',
                       'PREEMPTING', 'RECALLING', 'RECALLED',
                       'LOST']
        
        locations = dict()
        
        locations['p1'] = Pose(Point(-2.8, 0.6, 0.000),  Quaternion(0.000, 0.000, -0.7, 0.7)) 
        locations['p2'] = Pose(Point(-1.56, 0.21, 0.000),  Quaternion(0.000, 0.000, 1, 0)) 
        locations['p3'] = Pose(Point(-1.56, -1.25, 0.000),  Quaternion(0.000, 0.000, 1, 0))       
        locations['p4'] = Pose(Point(-2.8, -0.41, 0.000),  Quaternion(0.000, 0.000, 0.7, 0.7))       
        
        self.cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=5)

        self.move_base = actionlib.SimpleActionClient("move_base", MoveBaseAction)
        
        rospy.loginfo("Waiting for move_base action server...")

        self.move_base.wait_for_server(rospy.Duration(60))
        
        rospy.loginfo("Connected to move base server")

        initial_pose = PoseWithCovarianceStamped()

        n_locations = len(locations)
        n_goals = 0
        n_successes = 0
        i = 0
        distance_traveled = 0
        start_time = rospy.Time.now()
        running_time = 0
        location = ""
        last_location = ""
        
        # Get the initial pose from the user
        rospy.loginfo("*** Click the 2D Pose Estimate button in RViz to set the robot's initial pose...")
        rospy.wait_for_message('initialpose', PoseWithCovarianceStamped)
        self.last_location = Pose()
        rospy.Subscriber('initialpose', PoseWithCovarianceStamped, self.update_initial_pose)
        
        # Make sure we have the initial pose
        while initial_pose.header.stamp == "":
            rospy.sleep(1)
            
        rospy.loginfo("Starting navigation test")
        
        # Begin the main loop and run through a sequence of locations
        while not rospy.is_shutdown():
            if i == n_locations:
                i = 0
    
            sequence = ['p1','p2','p3','p4']
            
            # Get the next location in the current sequence
            location = sequence[i]
                        
            # Keep track of the distance traveled.
            # Use updated initial pose if available.
            if initial_pose.header.stamp == "":
                distance = sqrt(pow(locations[location].position.x - 
                                    locations[last_location].position.x, 2) +
                                pow(locations[location].position.y - 
                                    locations[last_location].position.y, 2))
            else:
                rospy.loginfo("Updating current pose.")
                distance = sqrt(pow(locations[location].position.x - 
                                    initial_pose.pose.pose.position.x, 2) +
                                pow(locations[location].position.y - 
                                    initial_pose.pose.pose.position.y, 2))
                initial_pose.header.stamp = ""
            
            # Store the last location for distance calculations
            last_location = location
            
            # Increment the counters
            i += 1
            n_goals += 1
        
            # Set up the next goal location
            self.goal = MoveBaseGoal()
            self.goal.target_pose.pose = locations[location]
            self.goal.target_pose.header.frame_id = 'map'
            self.goal.target_pose.header.stamp = rospy.Time.now()
            
            # Let the user know where the robot is going next
            rospy.loginfo("Going to: " + str(location))
            
            # Start the robot toward the next location
            self.move_base.send_goal(self.goal)           
            # Allow seconds to get there
            finished_within_time = self.move_base.wait_for_result(rospy.Duration(150)) 
#---------------------------------------------------       
            r = rospy.Rate(1)
            robot=Robot()
            pub = rospy.Publisher('/cmd_vel', Twist, queue_size=5)
            twist = Twist()
            while not rospy.is_shutdown():          
                x,y=robot.get_pos()            
                DIS=sqrt(pow(locations[location].position.x-x, 2) +pow(locations[location].position.y-y, 2))
                if DIS<0.3:
#                    self.move_base.cancel_goal()
                    rospy.loginfo("magnetic come on")      
#                    twist.linear.x = -0.05
#                    twist.linear.y = 0
#                    twist.linear.z = 0
#                    twist.angular.x = 0 
#                    twist.angular.y = 0 
#                    twist.angular.z = 0
 #                   pub.publish(twist)        
                if DIS<0.1:
                    rospy.loginfo("magnetic success")
                    break
                r.sleep()
            
#------------------------------------------


    def update_initial_pose(self, initial_pose):
        self.initial_pose = initial_pose

    def shutdown(self):
        rospy.loginfo("Stopping the robot...")
        self.move_base.cancel_goal()
        rospy.sleep(2)
        self.cmd_vel_pub.publish(Twist())
        rospy.sleep(1)
      
def trunc(f, n):
    # Truncates/pads a float f to n decimal places without rounding
    slen = len('%.*f' % (n, f))
    return float(str(f)[:slen])

if __name__ == '__main__':
    try:
        NavTest()
        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("AMCL navigation test finished.")
